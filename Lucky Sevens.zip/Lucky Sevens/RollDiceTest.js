﻿function rollDice() {
	return Math.floor(Math.random(1-6)Math.random(1-6));
}

for (var i=0; i<100; i++) {
	console.log(rollDice));
}
